class TeamMeeting {
  final String id;
  final String title;
  final DateTime start;
  final int minutes;
  final String host;
  final String location;
  final List<String> agenda;
  final MeetingMinutes? savedMinutes;
  final bool cancelled;

  const TeamMeeting({
    required this.id,
    required this.title,
    required this.start,
    required this.minutes,
    required this.host,
    required this.location,
    this.agenda = const [],
    this.savedMinutes,
    this.cancelled = false,
  });

  DateTime get end => start.add(Duration(minutes: minutes));

  bool get isLive {
    final now = DateTime.now();
    return !now.isBefore(start) && now.isBefore(end);
  }

  bool get isSaved => savedMinutes != null;
}

class MeetingMinutes {
  final String summary;
  final List<String> decisions;
  final List<MeetingAction> actions;

  const MeetingMinutes({
    required this.summary,
    this.decisions = const [],
    this.actions = const [],
  });
}

class MeetingAction {
  final String action;
  final String owner;
  final DateTime? due;

  const MeetingAction({required this.action, required this.owner, this.due});
}

/// Sample meetings until the office publishes them. The next one is today.
final List<TeamMeeting> teamMeetings = _build(DateTime.now());

List<TeamMeeting> _build(DateTime now) {
  final soon = now.add(const Duration(minutes: 27));
  final last = DateTime(now.year, now.month, now.day - 9, 10);
  return [
    TeamMeeting(
      id: 'M1',
      title: 'Monthly team meeting',
      start: soon,
      minutes: 60,
      host: 'Maria Reyes',
      location: 'WellTrust office, Kettering',
      agenda: const [
        'Rota and visit changes',
        'Recording medication and refusals',
        'Health and safety',
        'Feedback and concerns',
        'Any other business',
      ],
    ),
    TeamMeeting(
      id: 'M2',
      title: 'Medication and safeguarding refresher',
      start: DateTime(now.year, now.month, now.day + 7, 10),
      minutes: 60,
      host: 'Sarah Williams',
      location: 'Online',
      agenda: const [
        'Recording medication refusals',
        'Spotting and reporting safeguarding concerns',
      ],
    ),
    TeamMeeting(
      id: 'M3',
      title: 'Monthly team meeting (last month)',
      start: last,
      minutes: 60,
      host: 'Maria Reyes',
      location: 'WellTrust office, Kettering',
      agenda: const [
        'Visits and rota',
        'Training and supervision',
        'Health and safety',
        'Feedback',
        'Any other business',
      ],
      savedMinutes: MeetingMinutes(
        summary:
            'We reviewed last month\'s visits. One carer was reminded to record exact visit times. Moving and handling refreshers are booked for anyone outstanding. There were no new health and safety concerns.',
        decisions: [
          'Weekend bank staff onboarding will be prioritised before October.',
        ],
        actions: [
          MeetingAction(
            action: 'Schedule overdue supervisions',
            owner: 'Maria Reyes',
          ),
          MeetingAction(
            action: 'Complete the moving and handling refresher',
            owner: 'All carers',
          ),
        ],
      ),
    ),
  ];
}

/// The next meeting still to come today, if there is one.
TeamMeeting? meetingToday() {
  final now = DateTime.now();
  for (final m in teamMeetings) {
    final sameDay =
        m.start.year == now.year &&
        m.start.month == now.month &&
        m.start.day == now.day;
    if (sameDay && now.isBefore(m.end)) return m;
  }
  return null;
}
