/// Care handover between carers and the office.
enum HandoverKind { info, concern, change, todo, visitSummary }

enum HandoverPriority { routine, important, urgent }

extension HandoverKindLabel on HandoverKind {
  String get label => switch (this) {
    HandoverKind.info => 'Info',
    HandoverKind.concern => 'Concern',
    HandoverKind.change => 'Change',
    HandoverKind.todo => 'To do',
    HandoverKind.visitSummary => 'Visit summary',
  };
}

extension HandoverPriorityLabel on HandoverPriority {
  String get label => switch (this) {
    HandoverPriority.routine => 'Routine',
    HandoverPriority.important => 'Important',
    HandoverPriority.urgent => 'Urgent',
  };
}

class HandoverEntry {
  final String id;
  final String clientId;
  final DateTime at;
  final String by;
  final HandoverKind kind;
  final HandoverPriority priority;
  final String text;
  final Map<String, String> details;
  final bool needsFollowUp;
  final String followUpFor;
  final DateTime? followUpDue;
  final bool resolved;
  final String? resolvedBy;
  final DateTime? resolvedAt;
  final String resolutionNote;

  const HandoverEntry({
    required this.id,
    required this.clientId,
    required this.at,
    required this.by,
    required this.kind,
    required this.priority,
    required this.text,
    this.details = const {},
    this.needsFollowUp = false,
    this.followUpFor = 'Next carer',
    this.followUpDue,
    this.resolved = false,
    this.resolvedBy,
    this.resolvedAt,
    this.resolutionNote = '',
  });

  bool get isOpen =>
      !resolved &&
      (needsFollowUp ||
          kind == HandoverKind.concern ||
          kind == HandoverKind.todo ||
          priority == HandoverPriority.urgent);

  HandoverEntry markDone(
    String who, {
    DateTime? completedAt,
    String note = '',
  }) => HandoverEntry(
    id: id,
    clientId: clientId,
    at: at,
    by: by,
    kind: kind,
    priority: priority,
    text: text,
    details: details,
    needsFollowUp: needsFollowUp,
    followUpFor: followUpFor,
    followUpDue: followUpDue,
    resolved: true,
    resolvedBy: who,
    resolvedAt: completedAt ?? DateTime.now(),
    resolutionNote: note,
  );
}

class HandoverClient {
  final String id;
  final String name;
  final String preferred;
  final String address;
  final String phone;
  final List<String> alerts;
  final String nextVisit;
  final bool visitToday;

  const HandoverClient({
    required this.id,
    required this.name,
    required this.preferred,
    required this.address,
    required this.phone,
    required this.alerts,
    required this.nextVisit,
    this.visitToday = false,
  });
}

const handoverClients = <HandoverClient>[
  HandoverClient(
    id: 'U1',
    name: 'Mr Harold Fisher',
    preferred: 'Harold',
    address: '14 Rowan Close, Kettering',
    phone: '07700 900101',
    alerts: [
      'Uses a walking frame. Keep the hallway clear.',
      'Type 2 diabetes. Make sure he has eaten before his tablets.',
    ],
    nextVisit: 'Today 09:00',
    visitToday: true,
  ),
  HandoverClient(
    id: 'U2',
    name: 'Mrs Margaret Hensley',
    preferred: 'Margaret',
    address: '3 Elm Court, Kettering',
    phone: '07700 900102',
    alerts: [
      'Hoist transfers need two carers. Do not start until both of you are there.',
      'Pressure-relieving cushion on her chair. Check her heels and sacrum.',
    ],
    nextVisit: 'Today 10:00',
    visitToday: true,
  ),
  HandoverClient(
    id: 'U3',
    name: 'Mrs Dorothy Bell',
    preferred: 'Dorothy',
    address: '22 Meadow Lane, Kettering',
    phone: '07700 900103',
    alerts: [
      'Living with dementia. Introduce yourself each visit and explain what you are doing.',
      'May refuse tablets. Do not force. Record it and tell the office.',
    ],
    nextVisit: 'Today 13:00',
    visitToday: true,
  ),
  HandoverClient(
    id: 'U4',
    name: 'Mr Suresh Patel',
    preferred: 'Suresh',
    address: '8 Orchard Way, Kettering',
    phone: '07700 900104',
    alerts: [
      'Recovering from a stroke. Allow extra time for speech and dressing.',
    ],
    nextVisit: 'Tomorrow 17:30',
  ),
  HandoverClient(
    id: 'U5',
    name: 'Mrs Joan Whitmore',
    preferred: 'Joan',
    address: '61 Beech Road, Kettering',
    phone: '07700 900105',
    alerts: [
      'At risk of falls. Check her pendant alarm is worn every visit.',
      'Milo the cat may run out of the door.',
    ],
    nextVisit: 'Today',
    visitToday: true,
  ),
  HandoverClient(
    id: 'U6',
    name: 'Mr George Adeyemi',
    preferred: 'George',
    address: '5 Chestnut Grove, Kettering',
    phone: '07700 900106',
    alerts: ['Uses oxygen at night. No candles or naked flames.'],
    nextVisit: 'Thu 20:30',
  ),
];

List<HandoverEntry> sampleHandover() {
  final now = DateTime.now();
  DateTime ago(int h) => now.subtract(Duration(hours: h));
  return [
    HandoverEntry(
      id: 'H1',
      clientId: 'U1',
      at: ago(5),
      by: 'Sarah Williams',
      kind: HandoverKind.concern,
      priority: HandoverPriority.urgent,
      text:
          'Harold was more tired than usual and ate very little at lunch. Check his sugar readings and tell the office if they are low.',
      details: {
        'How they were': 'Low',
        'Food and drink': 'Little',
        'Medication': 'No issues',
      },
      needsFollowUp: true,
    ),
    HandoverEntry(
      id: 'H2',
      clientId: 'U1',
      at: ago(30),
      by: 'Office',
      kind: HandoverKind.todo,
      priority: HandoverPriority.important,
      text:
          'The GP is visiting on Tuesday at 11:00. Please make sure Harold is dressed and ready.',
      needsFollowUp: true,
      followUpFor: 'Anyone',
    ),
    HandoverEntry(
      id: 'H3',
      clientId: 'U1',
      at: ago(48),
      by: 'John Jones',
      kind: HandoverKind.info,
      priority: HandoverPriority.routine,
      text:
          'The new pressure-relieving cushion has arrived. Please keep it on his chair.',
      details: {'Home and equipment': 'Cushion is on the armchair'},
    ),
    HandoverEntry(
      id: 'H4',
      clientId: 'U2',
      at: ago(20),
      by: 'Office',
      kind: HandoverKind.change,
      priority: HandoverPriority.important,
      text:
          "Margaret's hoist sling has changed to the blue one. Check the label before every transfer.",
      details: {'Home and equipment': 'New blue sling'},
    ),
    HandoverEntry(
      id: 'H5',
      clientId: 'U2',
      at: ago(26),
      by: 'Sarah Williams',
      kind: HandoverKind.visitSummary,
      priority: HandoverPriority.routine,
      text:
          'Good visit. Skin is intact. She likes the bedroom window open in the mornings.',
      details: {
        'How they were': 'Settled',
        'Food and drink': 'Good',
        'Skin and mobility': 'No concerns',
      },
    ),
    HandoverEntry(
      id: 'H6',
      clientId: 'U3',
      at: ago(8),
      by: 'John Jones',
      kind: HandoverKind.concern,
      priority: HandoverPriority.important,
      text:
          'Dorothy refused her lunchtime tablets twice this week. This has been reported to the office. Do not force her. Record it each time.',
      details: {'Medication': 'Refused or missed', 'How they were': 'Anxious'},
      needsFollowUp: true,
      followUpFor: 'Office',
    ),
    HandoverEntry(
      id: 'H7',
      clientId: 'U3',
      at: ago(72),
      by: 'Office',
      kind: HandoverKind.info,
      priority: HandoverPriority.routine,
      text: 'Her daughter visits on Sundays and may want to talk about care.',
      details: {'Contact with family or others': 'Daughter visits on Sundays'},
    ),
    HandoverEntry(
      id: 'H8',
      clientId: 'U4',
      at: ago(40),
      by: 'David Eze',
      kind: HandoverKind.visitSummary,
      priority: HandoverPriority.routine,
      text:
          'His speech is improving. Give him time to answer and do not finish his sentences.',
      details: {'How they were': 'Settled'},
    ),
    HandoverEntry(
      id: 'H9',
      clientId: 'U5',
      at: ago(12),
      by: 'Office',
      kind: HandoverKind.change,
      priority: HandoverPriority.important,
      text:
          'Joan has a new pendant alarm. Test it at every visit and tell the office if it does not connect.',
      details: {'Home and equipment': 'New pendant alarm'},
      needsFollowUp: true,
    ),
    HandoverEntry(
      id: 'H10',
      clientId: 'U6',
      at: ago(48),
      by: 'Office',
      kind: HandoverKind.todo,
      priority: HandoverPriority.routine,
      text:
          'The oxygen supplier visits on Thursday morning. No candles or naked flames in the house.',
      details: {'Home and equipment': 'Oxygen delivery Thursday'},
      needsFollowUp: true,
      followUpFor: 'Anyone',
    ),
  ];
}
