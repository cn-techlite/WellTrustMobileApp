class MessageEntry {
  final String body;
  final DateTime at;
  final bool mine;

  const MessageEntry({
    required this.body,
    required this.at,
    required this.mine,
  });
}

class MessageThread {
  final String id;
  final String party;
  final String subject;
  final bool unread;
  final List<MessageEntry> entries;
  final String? actionLabel;
  final String? actionRoute;

  const MessageThread({
    required this.id,
    required this.party,
    required this.subject,
    required this.unread,
    required this.entries,
    this.actionLabel,
    this.actionRoute,
  });

  DateTime get lastAt => entries.last.at;
  MessageEntry get lastEntry => entries.last;

  MessageThread copyWith({bool? unread, List<MessageEntry>? entries}) =>
      MessageThread(
        id: id,
        party: party,
        subject: subject,
        unread: unread ?? this.unread,
        entries: entries ?? this.entries,
        actionLabel: actionLabel,
        actionRoute: actionRoute,
      );
}
