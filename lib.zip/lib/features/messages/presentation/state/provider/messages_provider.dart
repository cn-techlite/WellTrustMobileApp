import 'package:well_trust_mobile_app/core/utils/package_export.dart';
import 'package:well_trust_mobile_app/features/messages/data/model/message_thread.dart';

class MessagesNotifier extends Notifier<List<MessageThread>> {
  @override
  List<MessageThread> build() {
    final now = DateTime.now();
    return [
      MessageThread(
        id: 'N1',
        party: 'Management',
        subject: 'Your rota for next week',
        unread: true,
        actionLabel: 'Open the rota',
        actionRoute: 'rota',
        entries: [
          MessageEntry(
            body:
                'Next week\'s rota is now live. Please check your visits and acknowledge any changes.',
            at: now.subtract(const Duration(days: 1, hours: 1)),
            mine: false,
          ),
        ],
      ),
      MessageThread(
        id: 'N2',
        party: 'Admin',
        subject: 'Medication Training certificate',
        unread: true,
        actionLabel: 'Open My documents',
        actionRoute: 'documents',
        entries: [
          MessageEntry(
            body:
                'Your Medication Training certificate has expired. Please upload a new one so we can keep you on visits with medication.',
            at: now.subtract(const Duration(days: 2)),
            mine: false,
          ),
        ],
      ),
      MessageThread(
        id: 'N3',
        party: 'Office',
        subject: 'Key safe reminder',
        unread: true,
        entries: [
          MessageEntry(
            body:
                'Always close and scramble the key safe after use, and never say the code out loud where others can hear it.',
            at: now.subtract(const Duration(days: 4)),
            mine: false,
          ),
        ],
      ),
    ];
  }

  int get unreadCount => state.where((thread) => thread.unread).length;

  MessageThread? thread(String id) {
    for (final thread in state) {
      if (thread.id == id) return thread;
    }
    return null;
  }

  void markRead(String id) {
    state = [
      for (final thread in state)
        if (thread.id == id) thread.copyWith(unread: false) else thread,
    ];
  }

  void reply(String id, String body) {
    final text = body.trim();
    if (text.isEmpty) return;
    state = [
      for (final thread in state)
        if (thread.id == id)
          thread.copyWith(
            unread: false,
            entries: [
              ...thread.entries,
              MessageEntry(body: text, at: DateTime.now(), mine: true),
            ],
          )
        else
          thread,
    ];
  }

  String compose({
    required String to,
    required String subject,
    required String body,
  }) {
    final id = 'M${DateTime.now().microsecondsSinceEpoch}';
    state = [
      MessageThread(
        id: id,
        party: to,
        subject: subject.trim(),
        unread: false,
        entries: [
          MessageEntry(body: body.trim(), at: DateTime.now(), mine: true),
        ],
      ),
      ...state,
    ];
    return id;
  }
}

final messagesProvider =
    NotifierProvider<MessagesNotifier, List<MessageThread>>(
      MessagesNotifier.new,
    );

final unreadMessageCountProvider = Provider<int>(
  (ref) => ref.watch(messagesProvider).where((thread) => thread.unread).length,
);
