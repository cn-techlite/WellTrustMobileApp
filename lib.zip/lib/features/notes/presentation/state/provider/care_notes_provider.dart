import 'package:well_trust_mobile_app/core/utils/package_export.dart';
import 'package:well_trust_mobile_app/features/notes/data/model/care_note_entry.dart';

class CareNotesNotifier extends Notifier<List<CareNoteEntry>> {
  @override
  List<CareNoteEntry> build() => const [];

  void add(CareNoteEntry note) {
    state = [note, ...state];
  }
}

final careNotesProvider =
    NotifierProvider<CareNotesNotifier, List<CareNoteEntry>>(
      CareNotesNotifier.new,
    );
