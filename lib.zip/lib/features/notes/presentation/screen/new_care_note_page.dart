import 'package:well_trust_mobile_app/core/utils/colors.dart';
import 'package:well_trust_mobile_app/core/utils/package_export.dart';
import 'package:well_trust_mobile_app/features/handover/data/model/handover_model.dart';
import 'package:well_trust_mobile_app/features/handover/presentation/widget/handover_widgets.dart';
import 'package:well_trust_mobile_app/features/notes/data/model/care_note_entry.dart';
import 'package:well_trust_mobile_app/features/notes/presentation/state/provider/care_notes_provider.dart';
import 'package:well_trust_mobile_app/shared/widgets/input.dart';
import 'package:well_trust_mobile_app/shared/widgets/welltrust_app_bar.dart';

class NewCareNotePage extends ConsumerStatefulWidget {
  final String? clientId;

  const NewCareNotePage({super.key, this.clientId});

  @override
  ConsumerState<NewCareNotePage> createState() => _NewCareNotePageState();
}

class _NewCareNotePageState extends ConsumerState<NewCareNotePage> {
  final noteController = TextEditingController();

  String? clientId;
  String? mood;
  String? intake;
  String? skin;
  bool flagged = false;
  String? error;

  @override
  void initState() {
    super.initState();
    clientId = widget.clientId;
  }

  @override
  void dispose() {
    noteController.dispose();
    super.dispose();
  }

  void save() {
    if (clientId == null ||
        mood == null ||
        intake == null ||
        skin == null ||
        noteController.text.trim().isEmpty) {
      setState(() {
        error = 'Complete each question and write the care note.';
      });
      return;
    }

    final tellOffice = flagged || skin == 'Concern';
    ref
        .read(careNotesProvider.notifier)
        .add(
          CareNoteEntry(
            id: 'N${DateTime.now().microsecondsSinceEpoch}',
            clientId: clientId!,
            at: DateTime.now(),
            mood: mood!,
            intake: intake!,
            skin: skin!,
            text: noteController.text.trim(),
            flagged: tellOffice,
          ),
        );

    final messenger = ScaffoldMessenger.maybeOf(context);
    Navigator.pop(context);
    messenger?.showSnackBar(
      SnackBar(
        content: AppText(
          text: tellOffice
              ? 'Care note saved and flagged for the office.'
              : 'Care note saved.',
          type: AppTextType.bodySmall,
        ),
      ),
    );
  }

  Widget label(String value, {String? help}) => Padding(
    padding: const EdgeInsets.only(top: 16, bottom: 6),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AppText(
          text: value,
          type: AppTextType.bodySmall,
          fontWeight: FontWeight.w600,
          color: AppColors.ink,
        ),
        if (help != null) ...[
          addVerticalSpacing(0.24),
          AppText(
            text: help,
            type: AppTextType.labelLarge,
            color: AppColors.muted,
          ),
        ],
      ],
    ),
  );

  Widget segments(
    List<String> options,
    String? selected,
    ValueChanged<String> onChanged,
  ) {
    return Wrap(
      spacing: 6,
      runSpacing: 6,
      children: [
        for (final option in options)
          _CareNoteSegment(
            label: option,
            selected: option == selected,
            onSelected: () => setState(() {
              onChanged(option);
              error = null;
            }),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Column(
        children: [
          const WellTrustAppBar(title: 'New care note', showBack: true),
          Expanded(
            child: SafeArea(
              top: false,
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 36),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AppText(
                      text:
                          'Use this for something you noticed outside a visit, such as a phone call from a family member.',
                      type: AppTextType.bodySmall,
                      color: AppColors.muted,
                    ),
                    addVerticalSpacing(2.13),
                    DesignCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          label('Who is it about?'),
                          GlobalSearchableDropdown<String>(
                            title: 'Choose a person',
                            hintText: 'Choose a person',
                            value: clientId,
                            options: [
                              for (final client in handoverClients)
                                SearchableDropdownOption(
                                  value: client.id,
                                  label: client.name,
                                ),
                            ],
                            onChanged: (value) => setState(() {
                              clientId = value;
                              error = null;
                            }),
                          ),
                          label('How were they?'),
                          segments(
                            const ['Settled', 'Low', 'Anxious', 'Unwell'],
                            mood,
                            (value) => mood = value,
                          ),
                          label('Food and drink'),
                          segments(
                            const [
                              'Good',
                              'Some',
                              'Little',
                              'Refused',
                              'Not needed',
                            ],
                            intake,
                            (value) => intake = value,
                          ),
                          label('Skin and comfort'),
                          segments(
                            const ['No concerns', 'Concern'],
                            skin,
                            (value) => skin = value,
                          ),
                          label(
                            'What you did and how they were',
                            help:
                                'Write what happened. The office and other carers will read this.',
                          ),
                          GlobalTextField(
                            fieldName:
                                'For example: helped Harold wash and dress. He was in good spirits and ate all his breakfast.',
                            keyBoardType: TextInputType.multiline,
                            textController: noteController,
                            minLines: 5,
                            maxLines: 7,
                            maxLength: 1000,
                            removeSpace: false,
                            textCapitalization: TextCapitalization.sentences,
                            onChanged: (_) {
                              if (error != null) setState(() => error = null);
                            },
                          ),
                          addVerticalSpacing(1.90),
                          Material(
                            color: AppColors.bg,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: BorderSide(color: AppColors.line),
                            ),
                            clipBehavior: Clip.antiAlias,
                            child: CheckboxListTile(
                              value: flagged,
                              onChanged: (value) =>
                                  setState(() => flagged = value ?? false),
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 8,
                              ),
                              controlAffinity: ListTileControlAffinity.leading,
                              activeColor: AppColors.primary,
                              title: const AppText(
                                text:
                                    'Tell the office about this. Tick it for anything that worries you.',
                                type: AppTextType.bodySmall,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          if (error != null)
                            Padding(
                              padding: const EdgeInsets.only(top: 14),
                              child: AppText(
                                text: error!,
                                type: AppTextType.bodySmall,
                                color: AppColors.rose,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          addVerticalSpacing(2.61),
                          DesignButton('Save care note', onPressed: save),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CareNoteSegment extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onSelected;

  const _CareNoteSegment({
    required this.label,
    required this.selected,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    return ChoiceChip(
      label: AppText(
        text: label,
        type: AppTextType.labelLarge,
        color: selected ? AppColors.onPrimary : AppColors.ink,
        fontWeight: FontWeight.w600,
      ),
      selected: selected,
      showCheckmark: false,
      onSelected: (_) => onSelected(),
      selectedColor: AppColors.primary,
      backgroundColor: AppColors.surface,
      side: BorderSide(
        color: selected ? AppColors.primary : AppColors.line2,
        width: 1.5,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    );
  }
}
