class CareNoteEntry {
  final String id;
  final String clientId;
  final DateTime at;
  final String mood;
  final String intake;
  final String skin;
  final String text;
  final bool flagged;

  const CareNoteEntry({
    required this.id,
    required this.clientId,
    required this.at,
    required this.mood,
    required this.intake,
    required this.skin,
    required this.text,
    required this.flagged,
  });
}
